
import json
import time
import urllib.request
import urllib.parse

TOKEN = '7984837531:AAEoM9fpwlwhWUZXjUpIV1WJmSu2Tg1XQds'
API_URL = f'https://api.telegram.org/bot{TOKEN}/'

ADMIN_USERNAME = 'doxaase'
ADMIN_CHAT_ID = None

def load_json(filename):
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        return {}

def save_json(filename, data):
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

products = load_json('products.json')
carts = load_json('carts.json')
orders = load_json('orders.json')
user_states = {}
admin_states = {}

def send_request(method, params):
    data = urllib.parse.urlencode(params).encode()
    url = API_URL + method
    req = urllib.request.Request(url, data=data)
    with urllib.request.urlopen(req) as response:
        return json.loads(response.read())

def send_message(chat_id, text, reply_markup=None):
    params = {'chat_id': chat_id, 'text': text, 'parse_mode': 'HTML'}
    if reply_markup:
        params['reply_markup'] = json.dumps(reply_markup)
    send_request('sendMessage', params)

def send_photo(chat_id, photo_url, caption=None, reply_markup=None):
    params = {'chat_id': chat_id, 'photo': photo_url}
    if caption:
        params['caption'] = caption
        params['parse_mode'] = 'HTML'
    if reply_markup:
        params['reply_markup'] = json.dumps(reply_markup)
    send_request('sendPhoto', params)

def get_updates(offset=None):
    url = API_URL + 'getUpdates?timeout=100'
    if offset:
        url += f'&offset={offset}'
    try:
        with urllib.request.urlopen(url, timeout=120) as resp:
            return json.loads(resp.read())
    except:
        return {"result": []}

def build_keyboard(items):
    return {'keyboard': [[{'text': i}] for i in items], 'resize_keyboard': True, 'one_time_keyboard': True}

def build_inline_keyboard(buttons):
    return {'inline_keyboard': buttons}

def show_categories(chat_id):
    if not products:
        send_message(chat_id, "Товары ещё не добавлены.")
        return
    categories = list(products.keys())
    send_message(chat_id, "Выберите категорию:", build_keyboard(categories + ['Корзина']))

def show_products(chat_id, category):
    if category not in products:
        send_message(chat_id, "Категория не найдена.")
        return
    for pid, prod in products[category].items():
        caption = f"<b>{prod['name']}</b>
Цена: {prod['price']} см
ID: {pid}"
        kb = build_inline_keyboard([[{"text": "Купить", "callback_data": f"buy_{pid}"}]])
        if prod.get('photo'):
            send_photo(chat_id, prod['photo'], caption=caption, reply_markup=kb)
        else:
            send_message(chat_id, caption, kb)

def add_to_cart(user_id, pid):
    for cat in products.values():
        if pid in cat:
            carts.setdefault(user_id, {})
            carts[user_id][pid] = carts[user_id].get(pid, 0) + 1
            save_json('carts.json', carts)
            return f"Товар <b>{cat[pid]['name']}</b> добавлен в корзину."
    return "Товар не найден."

def show_cart(chat_id, user_id):
    cart = carts.get(user_id, {})
    if not cart:
        send_message(chat_id, "Ваша корзина пуста.")
        return
    text = "<b>Ваша корзина:</b>
"
    total = 0
    for pid, qty in cart.items():
        found = False
        for cat in products.values():
            if pid in cat:
                name = cat[pid]['name']
                price = cat[pid]['price']
                total += price * qty
                text += f"{name} x {qty} = {price * qty} см
"
                found = True
                break
        if not found:
            text += f"{pid} x {qty} (удален)
"
    text += f"
<b>Итого: {total} см</b>"
    kb = build_keyboard(['Оформить заказ', 'История заказов', '/list'])
    send_message(chat_id, text, kb)

def place_order(chat_id, user_id):
    if user_id not in carts or not carts[user_id]:
        send_message(chat_id, "Корзина пуста!")
        return
    user_states[user_id] = 'waiting_location'
    keyboard = {
        "keyboard": [[{"text": "Отправить местоположение", "request_location": True}]],
        "resize_keyboard": True,
        "one_time_keyboard": True
    }
    send_message(chat_id, "Пожалуйста, отправьте ваше местоположение или напишите адрес.", keyboard)

def show_history(chat_id, user_id):
    user_orders = orders.get(user_id, {})
    if not user_orders:
        send_message(chat_id, "У вас нет заказов.")
        return
    text = "<b>История заказов:</b>
"
    for oid, order in user_orders.items():
        text += f"Заказ {oid} ({order['timestamp']}):
"
        for pid, qty in order['items'].items():
            found = False
            for cat in products.values():
                if pid in cat:
                    text += f" - {cat[pid]['name']} x {qty}
"
                    found = True
                    break
            if not found:
                text += f" - {pid} x {qty} (удален)
"
        if 'location' in order:
            lat, lon = order['location']
            text += f" Местоположение: https://maps.google.com/?q={lat},{lon}
"
        elif 'location_text' in order:
            text += f" Адрес: {order['location_text']}
"
    send_message(chat_id, text)

def process_order(chat_id, user_id, location_data, username):
    cart = carts.get(user_id, {})
    if not cart:
        send_message(chat_id, "Корзина пуста. Заказ отменён.")
        user_states[user_id] = None
        return

    order_text = f"<b>Новый заказ от @{username or user_id}</b>
"
    if isinstance(location_data, tuple):
        lat, lon = location_data
        order_text += f"Местоположение: https://maps.google.com/?q={lat},{lon}

"
    else:
        order_text += f"Адрес: {location_data}

"

    total = 0
    for pid, qty in cart.items():
        found = False
        for cat in products.values():
            if pid in cat:
                name = cat[pid]['name']
                price = cat[pid]['price']
                total += price * qty
                order_text += f"{name} x {qty} = {price * qty} см
"
                found = True
                break
        if not found:
            order_text += f"{pid} x {qty} (удален)
"
    order_text += f"
<b>Итого: {total} см</b>"

    order_id = str(int(time.time()))
    orders.setdefault(user_id, {})[order_id] = {
        'items': cart,
        'timestamp': time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
    }
    if isinstance(location_data, tuple):
        orders[user_id][order_id]['location'] = location_data
    else:
        orders[user_id][order_id]['location_text'] = location_data

    save_json('orders.json', orders)
    carts[user_id] = {}
    save_json('carts.json', carts)

    send_message(chat_id, "Спасибо! Ваш заказ принят и отправлен администратору.")

    global ADMIN_CHAT_ID
    if ADMIN_CHAT_ID:
        send_message(ADMIN_CHAT_ID, order_text)
    else:
        send_message(chat_id, "Ошибка: администратор не найден.")

    user_states[user_id] = None

def handle_callback(update):
    callback = update['callback_query']
    data = callback['data']
    chat_id = callback['message']['chat']['id']
    user_id = str(chat_id)

    if data.startswith('buy_'):
        pid = data[4:]
        msg = add_to_cart(user_id, pid)
        send_message(chat_id, msg)

def handle_message(message):
    global ADMIN_CHAT_ID
    chat_id = message['chat']['id']
    text = message.get('text', '').strip()
    username = message['from'].get('username', '').lower()
    user_id = str(chat_id)

    if username == ADMIN_USERNAME and ADMIN_CHAT_ID is None:
        ADMIN_CHAT_ID = chat_id
        send_message(chat_id, "Администратор зарегистрирован.")

    if user_states.get(user_id) == 'waiting_location':
        if 'location' in message:
            loc = message['location']
            lat, lon = loc['latitude'], loc['longitude']
            process_order(chat_id, user_id, (lat, lon), username)
        elif text:
            process_order(chat_id, user_id, text, username)
        else:
            send_message(chat_id, "Пожалуйста, отправьте местоположение или адрес.")
        return

    if username == ADMIN_USERNAME:
        if user_id in admin_states:
            state = admin_states[user_id]
            if state['mode'] == 'add_category':
                cat = text
                if cat not in products:
                    products[cat] = {}
                    save_json('products.json', products)
                    send_message(chat_id, f"Категория <b>{cat}</b> добавлена.")
                else:
                    send_message(chat_id, "Такая категория уже есть.")
                del admin_states[user_id]
                return
            if state['mode'] == 'add_photo':
                pid = state['product_id']
                for cat in products:
                    if pid in products[cat]:
                        products[cat][pid]['photo'] = text
                        save_json('products.json', products)
                        send_message(chat_id, "Фото добавлено.")
                        break
                del admin_states[user_id]
                return
        if text == '/add_category':
            admin_states[user_id] = {'mode': 'add_category'}
            send_message(chat_id, "Введите название новой категории:")
            return
        if text.startswith('/add_photo '):
            pid = text.split(maxsplit=1)[1]
            admin_states[user_id] = {'mode': 'add_photo', 'product_id': pid}
            send_message(chat_id, "Отправьте ссылку на фото:")
            return

    if text == '/start' or text.lower() == 'назад':
        show_categories(chat_id)
    elif text in products:
        show_products(chat_id, text)
    elif text == 'Корзина':
        show_cart(chat_id, user_id)
    elif text == 'Оформить заказ':
        place_order(chat_id, user_id)
    elif text == 'История заказов':
        show_history(chat_id, user_id)
    elif text == '/list':
        show_categories(chat_id)
    else:
        send_message(chat_id, "Команда не распознана. Используйте меню.")

def main():
    offset = None
    print("Бот запущен")
    while True:
        updates = get_updates(offset)
        for update in updates['result']:
            offset = update['update_id'] + 1
            if 'callback_query' in update:
                handle_callback(update)
            elif 'message' in update:
                handle_message(update['message'])

if __name__ == '__main__':
    main()
